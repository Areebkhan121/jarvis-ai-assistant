"""Daily briefing built only from data actually stored in the database."""
from . import db


def build_briefing(path=None):
    with db.connect(path) as c:
        emails = c.execute("SELECT * FROM emails ORDER BY priority DESC").fetchall()
        tasks = c.execute("SELECT * FROM tasks WHERE status='pending' ORDER BY due").fetchall()
    if not emails and not tasks:
        return "No data yet. Load demo data or connect Gmail."
    lines = [f"You have {len(emails)} emails and {len(tasks)} pending tasks."]
    top = [e for e in emails if e["priority"] >= 60][:3]
    if top:
        lines.append("Top priorities:")
        lines += [f"- [{e['priority']}] {e['subject']} ({e['reason']})" for e in top]
    reply = [e for e in emails if e["needs_reply"]]
    lines.append(f"{len(reply)} email(s) deserve a reply.")
    if tasks:
        lines.append("Next task: " + f"{tasks[0]['title']} (due {tasks[0]['due']})")
    return "\n".join(lines)
