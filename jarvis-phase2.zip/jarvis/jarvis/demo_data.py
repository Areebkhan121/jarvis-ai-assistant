"""Synthetic demo data. Clearly fake; flagged is_demo=1 in the database."""
from datetime import datetime, timedelta, timezone

from . import db
from .scoring import score_email

DEMO_EMAILS = [
    ("recruiter@acme-demo.test", "Interview invitation: Business Development Manager", "Can you join an interview on Friday? Please confirm by Wednesday deadline."),
    ("hr@startup-demo.test", "Offer letter attached", "We are pleased to share the offer details. Could you reply with questions?"),
    ("billing@utility-demo.test", "Invoice due this week", "Your invoice is ready. Payment deadline is Friday."),
    ("prof@college-demo.test", "Meeting about your project", "Can we have a meeting Thursday to review your project?"),
    ("news@weekly-demo.test", "Weekly newsletter: 10 sales tips", "Read our newsletter. Click unsubscribe to stop."),
    ("promo@shop-demo.test", "Big sale this weekend", "Huge sale on everything. Unsubscribe anytime."),
]
DEMO_TASKS = [
    ("Reply to recruiter about interview slot", 1),
    ("Pay utility invoice", 3),
    ("Prepare for project meeting", 2),
]


def load_demo(path=None):
    now = datetime.now(timezone.utc)
    with db.connect(path) as c:
        c.execute("DELETE FROM emails WHERE is_demo=1")
        c.execute("DELETE FROM tasks WHERE is_demo=1")
        for i, (s, subj, snip) in enumerate(DEMO_EMAILS):
            r = score_email(s, subj, snip)
            c.execute("INSERT INTO emails VALUES (?,?,?,?,?,?,?,?,?,1)",
                      (f"demo-{i}", s, subj, snip, (now - timedelta(hours=i * 3)).isoformat(timespec="seconds"),
                       r["category"], r["priority"], r["reason"], r["needs_reply"]))
        for title, days in DEMO_TASKS:
            c.execute("INSERT INTO tasks(title, due, source, is_demo) VALUES (?,?,?,1)",
                      (title, (now + timedelta(days=days)).date().isoformat(), "demo"))
    db.log("load_demo", "Loaded synthetic demo data", path)
