"""SQLite storage for emails, tasks, and the audit log."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS emails (
    id TEXT PRIMARY KEY, sender TEXT, subject TEXT, snippet TEXT,
    received_at TEXT, category TEXT, priority INTEGER, reason TEXT,
    needs_reply INTEGER DEFAULT 0, is_demo INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due TEXT,
    status TEXT DEFAULT 'pending', source TEXT, is_demo INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, action TEXT, detail TEXT
);
"""


@contextmanager
def connect(path=None):
    conn = sqlite3.connect(str(path or config.DB_PATH))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(path=None):
    if path is None:
        config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as c:
        c.executescript(SCHEMA)


def log(action, detail="", path=None):
    """Audit entry. Keep detail short; never store email bodies or secrets."""
    with connect(path) as c:
        c.execute("INSERT INTO audit_log(ts, action, detail) VALUES (?,?,?)",
                  (datetime.now(timezone.utc).isoformat(timespec="seconds"), action, detail[:200]))
