"""Transparent rule-based email scoring (every score comes with reasons)."""
RULES = [
    ("interview", "job", 30, "mentions an interview"),
    ("offer", "job", 25, "mentions an offer"),
    ("recruiter", "job", 20, "from a recruiter"),
    ("deadline", None, 20, "contains a deadline"),
    ("urgent", None, 20, "marked urgent"),
    ("invoice", "bill", 15, "looks like a bill"),
    ("meeting", "meeting", 15, "meeting request"),
    ("newsletter", "newsletter", -30, "newsletter"),
    ("unsubscribe", "promotion", -30, "promotional"),
    ("sale", "promotion", -25, "promotional"),
]


def score_email(sender, subject, snippet):
    text = f"{sender} {subject} {snippet}".lower()
    score, category, reasons = 40, "other", []
    for kw, cat, pts, why in RULES:
        if kw in text:
            score += pts
            reasons.append(f"{pts:+d}: {why}")
            if cat and category == "other":
                category = cat
    if "?" in subject + snippet:
        score += 10
        reasons.append("+10: asks a question")
    score = max(0, min(100, score))
    needs_reply = int(score >= 60 and category not in ("newsletter", "promotion"))
    return {"priority": score, "category": category,
            "reason": "; ".join(reasons) or "no strong signals", "needs_reply": needs_reply}
