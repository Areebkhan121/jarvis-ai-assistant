"""Central configuration. Secrets come from environment variables only."""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # python-dotenv is optional for tests
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("JARVIS_DB", BASE_DIR / "data" / "jarvis.db"))
MODE = os.getenv("JARVIS_MODE", "demo")  # demo = synthetic data only
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "gemini").strip().lower()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
