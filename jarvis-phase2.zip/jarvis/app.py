"""JARVIS command center: Phase 1 dashboard + Phase 2 chat/productivity."""
import pandas as pd
import streamlit as st

from jarvis import config, db
from jarvis.ai import AIUnavailable, generate_answer
from jarvis.briefing import build_briefing
from jarvis.demo_data import load_demo
from jarvis.productivity import build_context, get_productivity_snapshot, offline_answer

st.set_page_config(page_title="JARVIS", page_icon="🤖", layout="wide")
db.init_db()

st.title("🤖 JARVIS Command Center")
st.caption("Personal email intelligence and productivity assistant · Phase 1–2")
snapshot = get_productivity_snapshot()
c1, c2, c3, c4 = st.columns(4)
c1.metric("Mode", config.MODE.upper())
c2.metric("Stored emails", snapshot["email_count"])
c3.metric("Needs reply", snapshot["reply_count"])
c4.metric("Pending tasks", snapshot["pending_task_count"])

with st.sidebar:
    st.header("Controls")
    if st.button("Load demo data", use_container_width=True):
        load_demo()
        st.success("Demo data loaded (synthetic).")
        st.rerun()
    if st.button("Refresh dashboard", use_container_width=True):
        st.rerun()
    st.divider()
    st.caption("Gmail: not connected. Phase 2 chat uses stored data only.")
    if config.GEMINI_API_KEY:
        st.success(f"AI configured · {config.GEMINI_MODEL}")
    else:
        st.info("AI offline mode. Add GEMINI_API_KEY to .env for Gemini chat.")
    st.caption("JARVIS does not send, delete, or modify emails in this phase.")


def show(query):
    with db.connect() as c:
        rows = c.execute(query).fetchall()
    if rows:
        st.dataframe(pd.DataFrame([dict(r) for r in rows]), use_container_width=True, hide_index=True)
    else:
        st.info("No records yet. Load demo data from the sidebar.")


tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    ["Briefing", "AI Chat", "Productivity", "Emails", "Tasks", "Audit log"]
)
with tab1:
    st.subheader("Your briefing")
    st.text(build_briefing())
    st.caption("Briefing statistics come from the local database; demo records are synthetic.")

with tab2:
    st.subheader("Talk to JARVIS")
    st.write("Ask about stored emails, replies, priorities, and pending tasks.")
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    prompt = st.chat_input("Ask JARVIS about your inbox or tasks...")
    if prompt:
        st.session_state.chat_history.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            with st.spinner("Checking stored data..."):
                context = build_context()
                try:
                    if config.LLM_PROVIDER != "gemini":
                        raise AIUnavailable("This build currently enables Gemini as the hosted provider.")
                    answer = generate_answer(prompt, context)
                except AIUnavailable:
                    answer = offline_answer(prompt)
                st.markdown(answer)
        st.session_state.chat_history.append({"role": "assistant", "content": answer})
    if st.button("Clear chat history"):
        st.session_state.chat_history = []
        st.rerun()

with tab3:
    st.subheader("Productivity engine")
    snap = get_productivity_snapshot()
    a, b, c, d = st.columns(4)
    a.metric("High priority", snap["high_priority_count"])
    b.metric("Reply candidates", snap["reply_count"])
    c.metric("Low priority", snap["low_priority_count"])
    d.metric("Pending tasks", snap["pending_task_count"])
    st.markdown("### Recommended next actions")
    if snap["recommendations"]:
        for i, item in enumerate(snap["recommendations"], 1):
            with st.container(border=True):
                st.markdown(f"**{i}. {item['title']}** · {item['type']} · Priority {item['priority']}/100")
                st.write(item["reason"])
                st.caption(item["action"])
    else:
        st.info("No recommendations yet. Load demo data or add tasks and emails in a future integration phase.")
    st.caption("Recommendations are rule-based and explainable; review them before acting.")

with tab4:
    show("SELECT sender, subject, category, priority, reason, needs_reply, is_demo FROM emails ORDER BY priority DESC")
with tab5:
    show("SELECT title, due, status, source, is_demo FROM tasks ORDER BY due")
with tab6:
    show("SELECT ts, action, detail FROM audit_log ORDER BY id DESC LIMIT 50")
