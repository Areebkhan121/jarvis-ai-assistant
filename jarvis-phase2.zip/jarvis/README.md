# JARVIS — Phase 1 + Phase 2

A local Streamlit dashboard with synthetic demo emails/tasks, transparent rule-based scoring, a productivity recommendation engine, and optional Gemini-powered chat. Gmail is **not connected** in this version. The app cannot send, delete, or modify emails.

## Requirements
- Windows 10/11
- Python 3.11 or newer
- Internet only to install dependencies and use Gemini; offline demo/productivity features work without an API key after dependencies are installed.

## Install (Windows PowerShell)
Open PowerShell in the extracted `jarvis` folder and run:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If PowerShell blocks activation, use `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` and try again, or run `.venv\Scripts\python.exe -m streamlit run app.py` without activation.

## Run

```powershell
streamlit run app.py
```

Click **Load demo data** in the sidebar. Open **AI Chat** to ask about the synthetic inbox. The **Productivity** tab ranks reply candidates and pending tasks.

## Enable Gemini chat (optional)
1. Obtain an API key from Google's official AI developer portal.
2. Open `.env` in a text editor and set `GEMINI_API_KEY=your_key_here`.
3. Keep the key private; never paste it into chat or commit `.env` to Git.
4. Restart Streamlit. The sidebar should indicate that AI is configured.

If the key is missing or Gemini is unavailable, JARVIS uses an honest offline fallback for common inbox/productivity questions. Open-ended answers require the hosted model. Check the current provider's pricing, availability, and terms before use; free-tier limits can change.

## Test

```powershell
python -m unittest discover -s tests -t . -v
```

## Security and limitations
- All current demo emails are synthetic and clearly flagged in the database.
- No Gmail integration exists yet. Do not treat demo data as real messages.
- When Gemini is enabled, the bounded local context (email sender, subject, snippets, scores, and tasks) is sent to the configured AI provider to answer chat questions. Do not use sensitive real data until you have reviewed the provider's privacy terms and the data flow.
- Emails are untrusted content; the prompt instructs the model not to follow embedded instructions. Prompt injection defenses are not perfect.
- No sending, deletion, forwarding, attachment execution, or other external email actions are implemented.
- `.env` is excluded by `.gitignore`. Keep it private.

## Project layout

```text
jarvis/
  app.py
  requirements.txt
  .env.example
  jarvis/
    ai.py              # Optional Gemini adapter
    productivity.py    # Data snapshot, recommendations, offline answers
    briefing.py        # Database-grounded briefing
    scoring.py         # Transparent email scoring
    db.py               # SQLite schema and audit log
    demo_data.py        # Synthetic demo dataset
    config.py           # Environment-based settings
  tests/
```

## Roadmap
- Phase 3: Gmail OAuth read-only integration.
- Phase 4: improved classification and editable reply drafts.
- Phase 5: explicit approval for external actions.
- Phase 6: scheduling, reminders, optional voice.
- Phase 7: security review and hardening.
