import os
import tempfile
import unittest

from jarvis import db
from jarvis.briefing import build_briefing
from jarvis.demo_data import load_demo
from jarvis.scoring import score_email


class Phase1Tests(unittest.TestCase):
    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(), "t.db")
        db.init_db(self.path)

    def test_interview_scores_high_with_reason(self):
        r = score_email("recruiter@x.test", "Interview invitation", "deadline Wednesday")
        self.assertGreaterEqual(r["priority"], 80)
        self.assertIn("interview", r["reason"])

    def test_newsletter_scores_low(self):
        r = score_email("news@x.test", "Weekly newsletter", "unsubscribe")
        self.assertLess(r["priority"], 30)
        self.assertEqual(r["needs_reply"], 0)

    def test_empty_briefing_is_honest(self):
        self.assertIn("No data yet", build_briefing(self.path))

    def test_demo_load_is_idempotent(self):
        load_demo(self.path)
        load_demo(self.path)
        with db.connect(self.path) as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM emails").fetchone()[0], 6)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0], 2)
        self.assertIn("6 emails", build_briefing(self.path))


if __name__ == "__main__":
    unittest.main()
