import os
import tempfile
import unittest
from unittest.mock import patch

from jarvis import db
from jarvis.demo_data import load_demo
from jarvis.productivity import build_context, get_productivity_snapshot, offline_answer
from jarvis.ai import AIUnavailable, generate_answer


class Phase2Tests(unittest.TestCase):
    def setUp(self):
        self.path = os.path.join(tempfile.mkdtemp(), "phase2.db")
        db.init_db(self.path)
        load_demo(self.path)

    def test_productivity_counts_real_stored_data(self):
        s = get_productivity_snapshot(self.path)
        self.assertEqual(s["email_count"], 6)
        self.assertGreater(s["reply_count"], 0)
        self.assertEqual(s["pending_task_count"], 3)

    def test_context_contains_database_facts(self):
        context = build_context(self.path)
        self.assertIn("Stored emails: 6", context)
        self.assertIn("Interview invitation", context)

    def test_offline_reply_answer_is_grounded(self):
        answer = offline_answer("Which emails should I reply to?", self.path)
        self.assertIn("marked as needing a reply", answer)
        self.assertIn("I have not sent", answer)

    def test_missing_key_fails_clearly(self):
        with patch("jarvis.ai.config.GEMINI_API_KEY", ""):
            with self.assertRaises(AIUnavailable):
                generate_answer("hello", "Stored emails: 0")


if __name__ == "__main__":
    unittest.main()
